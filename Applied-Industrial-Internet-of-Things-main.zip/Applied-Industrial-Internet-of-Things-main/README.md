Aim :
To design and simulate a room automation system in Cisco Packet Tracer that automatically manages the fan and room lamp based on sensor inputs, 
enabling efficient remote monitoring and energy saving.

Result :
The Room Automation System was successfully simulated in Cisco Packet Tracer. When the door was opened, both the fan and the lamp automatically turned ON. 
When the door was closed, the devices switched OFF.Remote monitoring and manual control of the fan and lamp were also achieved through the IoT server,
ensuring convenience and energy efficiency.
